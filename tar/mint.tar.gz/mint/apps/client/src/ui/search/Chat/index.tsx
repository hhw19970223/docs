'use client';

import { uniqueId } from 'lodash';
import { ChevronLeftIcon } from 'lucide-react';
import { KeyboardEvent, useCallback, useContext, useEffect, useState } from 'react';

import { AuthContext, DeploymentMetadataContext } from '@/contexts/ConfigContext';
import { NavigationContext, useSelectedLocale } from '@/contexts/NavigationContext';
import { NEXT_PUBLIC } from '@/env';
import { useAnalyticsContext } from '@/hooks/useAnalyticsContext';
import { useUserGroups } from '@/hooks/useUserGroups';
import { getTopicMessages } from '@/utils/chat/trieve';
import { cn } from '@/utils/cn';

import { ChatItem } from './ChatItem';

export function Chat({
  message,
  sharedSessionId,
  onBack,
  onClose,
}: {
  message: string;
  sharedSessionId?: string;
  onBack: () => void;
  onClose: () => void;
}) {
  const { askAFollowUpQuestion } = useSelectedLocale();
  const { selectedVersion } = useContext(NavigationContext);
  const { trieve, subdomain } = useContext(DeploymentMetadataContext);
  const { userInfo } = useContext(AuthContext);
  const [sessionId, setSessionId] = useState<string>();
  const [followupMessage, setFollowupMessage] = useState('');
  const [messages, setMessages] = useState<
    {
      message: string;
      initialResponse?: string;
      key: string;
    }[]
  >([
    {
      message,
      key: uniqueId(),
    },
  ]);
  const trackChatFollowup = useAnalyticsContext('chat_followup');
  const isCli = NEXT_PUBLIC.ENV === 'cli';

  const [isContentScrolled, setIsContentScrolled] = useState(false);

  const userGroups = useUserGroups();

  useEffect(() => {
    const fetchMessagesFromTopic = async () => {
      if (!sharedSessionId || !subdomain) return;
      const messages = await getTopicMessages(subdomain, sharedSessionId);
      if (messages) {
        const newMessages = messages.map((message) => ({
          message: message.query,
          initialResponse: message.response,
          key: uniqueId(),
        }));
        setMessages(newMessages);
      }
    };

    if (sharedSessionId) {
      void fetchMessagesFromTopic();
    }
  }, [sharedSessionId, subdomain]);

  const onSendFollowupMessage = useCallback(
    (message: string) => {
      setMessages([
        {
          message: message,
          key: uniqueId(),
        },
        ...messages,
      ]);

      void trackChatFollowup({
        query: message,
      });

      setFollowupMessage('');
    },
    [messages, trackChatFollowup]
  );

  const onSendRetryMessage = useCallback(
    (index: number) => {
      const newMessages = messages.slice();
      newMessages[index] = {
        message: newMessages[index]?.message || '',
        key: uniqueId(),
      };
      setMessages(newMessages);
    },
    [messages]
  );

  const onEnter = useCallback(
    (event: KeyboardEvent<HTMLInputElement>) => {
      if (event.key === 'Enter') {
        onSendFollowupMessage(followupMessage);
      } else if (event.key === 'Escape') {
        onClose();
      }
    },
    [onClose, onSendFollowupMessage, followupMessage]
  );

  return (
    <>
      <div
        className={cn(
          'p-2 h-18 relative z-10 border-transparent border-b transition',
          isContentScrolled && 'border-gray-200 dark:border-white/10'
        )}
      >
        <button
          className="absolute left-6 top-1/2 -translate-y-1/2 bg-gray-100 dark:bg-white/5 hover:bg-gray-200 dark:hover:bg-white/10 px-1.5 py-1.5 rounded-md"
          onClick={onBack}
        >
          <ChevronLeftIcon
            size={12}
            absoluteStrokeWidth
            strokeWidth={1.5}
            className="text-gray-950 dark:text-white opacity-70"
          />
        </button>
        <input
          className={cn(
            'rounded-xl border border-gray-200 dark:border-white/10 bg-white dark:bg-gray-950 h-full w-full outline-none text-gray-950 dark:text-white placeholder:text-gray-400 placeholder:dark:text-white/50 tracking-tight pl-12 pr-14 focus:border-gray-950 dark:focus:border-white disabled:text-gray-500 dark:disabled:text-white/50',
            !isContentScrolled && 'shadow-search',
            isCli && 'bg-zinc-100 dark:bg-zinc-900'
          )}
          disabled={isCli}
          placeholder={isCli ? 'Not available on local preview' : askAFollowUpQuestion}
          autoComplete="off"
          value={followupMessage}
          onChange={(e) => {
            setFollowupMessage(e.target.value);
          }}
          onKeyDown={onEnter}
        />
      </div>
      <div
        className="px-2 flex flex-col gap-2 max-h-[648px] overflow-y-auto"
        onScroll={(e) => {
          if (e.currentTarget.scrollTop) setIsContentScrolled(true);
          else setIsContentScrolled(false);
        }}
      >
        {trieve?.datasetId &&
          messages.map(({ message, key, initialResponse }, i) => (
            <ChatItem
              message={message}
              key={key}
              sessionId={sessionId || ''}
              subdomain={subdomain || ''}
              version={selectedVersion}
              initialResponse={initialResponse}
              setSessionId={setSessionId}
              className="last:mb-2"
              onGeneratingErrorRetry={() => onSendRetryMessage(i)}
              onCitationClick={onClose}
              userGroups={userGroups}
              isAuthenticated={!!userInfo}
            />
          ))}
      </div>
    </>
  );
}
